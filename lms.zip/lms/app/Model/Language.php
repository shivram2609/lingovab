<?php
App::uses('AppModel', 'Model');
/**
 * Language Model
 *
 */
class Language extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'title';

}
