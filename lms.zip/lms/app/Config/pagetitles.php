<?php
/* title extension for all pages in admin panel */
	define("TITLE_EXT"," | LMS");
	define("MAIL_TITLE_EXT"," LMS");
	define("ADMINLOGIN","Admin Login");
	define("FORGOTPASSWORD","Forgot Password");
	define("DASHBOARD","Dashboard");
	define("CHANGEPASSWORD","Change Password");
/* end here */

/* title for email templates (Admin) */
	define("EMAIL_INDEX_TITLE","Email Templates");
	define("EMAIL_ADD_TITLE","Add Email Templates");
	define("EMAIL_EDIT_TITLE","Edit Email Templates");
/* title for email templates (Admin) */

/* title for cmspages (Admin) */
	define("PAGES_INDEX_TITLE","Pages");
	define("PAGES_ADD_TITLE","Add Pages");
	define("PAGES_EDIT_TITLE","Edit Pages");
/* title for email templates (Admin) */
?>
