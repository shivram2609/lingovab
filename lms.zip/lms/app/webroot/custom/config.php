<?php 
define("SITE_COMMISSION","10");
define("INSTRUCTOR_COMMISSION","5");
define("CONTACT_MAIL","shivamsharma@zapbuild.com");
define("API_USERNAME","1337institute_api1.gmail.com");
define("API_PASSWORD","24GFY3LNUVNFNGYW");
define("API_SIGNATURE","Ai1PaghZh5FmBLCDCTQpwG8jB264AAkxBWf2X2f5XXjiDKBIdDQSULAb");
define("API_APPLICATIONID","APP-01E46180E9268854Y");
define("PAYPAL_DEVELOPER_EMAIL","1337institute@gmail.com");
define("API_MODE","live");
define("FACEBOOK_API_KEY","392296474215871");
define("FACEBOOK_SECRET_KEY","c75b545cd09cfb3ef89e396432a37497");
define("TWITTER_API_ID","CSpbRJK5eAEod91O7js5Gg");
define("TWITTER_SECRET_KEY","8KGhKpPzYRDX6FYkPVXTzvELN1D7pXtA78SYSnq44");
define("HOMEPAGE_BANNER_IMAGE_TEXT1","<span>The Elite Site for</span> Premium<br>
                    Technology<br>
                    Courses");
define("HOMEPAGE_BANNER_IMAGE1","/img/banners/bannerimage39.jpg");
define("HOMEPAGE_BANNER_IMAGE_LINK1","Test Text1");
define("HOMEPAGE_BANNER_IMAGE_LINK_VAL1","http://google.com");
define("HOMEPAGE_BANNER_IMAGE_TEXT2","<span>The Elite Site for</span> Premium<br>
                    Technology<br>
                    Courses");
define("HOMEPAGE_BANNER_IMAGE2","/img/banners/bannerimage16.jpg");
define("HOMEPAGE_BANNER_IMAGE_LINK2","Test Text2");
define("HOMEPAGE_BANNER_IMAGE_LINK_VAL2","http://yahoo.com");
define("HOMEPAGE_BANNER_IMAGE_TEXT3","<span>The Elite Site for</span> Premium<br>
                    Technology<br>
                    Courses");
define("HOMEPAGE_BANNER_IMAGE3","/img/banners/bannerimage17.jpg");
define("HOMEPAGE_BANNER_IMAGE_LINK3","Test Text 3");
define("HOMEPAGE_BANNER_IMAGE_LINK_VAL3","http://zapbuild.com");
define("HOMEPAGE_BANNER_IMAGE_TEXT4","<span>The Elite Site for</span> Premium<br>
                    Technology<br>
                    Courses");
define("HOMEPAGE_BANNER_IMAGE4","/img/banners/bannerimage18.jpg");
define("HOMEPAGE_BANNER_IMAGE_LINK4","Test Text 4");
define("HOMEPAGE_BANNER_IMAGE_LINK_VAL4","http://facebook.com");
define("SEO_META_TITLE","1337 institute of technology");
define("SEO_META_DESC","1337 institute of technology");
define("SEO_META_KEYWORD","1337 institute of technology");
define('RETURN_URL','http://localhost/1337IOT/trunk/');
define('CENCEL_URL','http://localhost/1337IOT/trunk/');
?>