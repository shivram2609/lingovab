<script type="text/javascript" >
function getPath(){		     
	var setup= {
		file: "http://localhost/1337iot/trunk/files/mashup_videos/2013-08-07-13060312_Saal_Bilal_Saeed.mp4",
		doc: "http://localhost/1337iot/trunk/files/mashup_images_xml/StoneyPointdetails.xml"
	}
	return setup;
}    
</script> 
        <script type="text/javascript" src="http://localhost/1337iot/trunk/files/bin-debug/swfobject.js"></script>
        <script type="text/javascript">
            <!-- For version detection, set to min. required Flash Player version, or 0 (or 0.0.0), for no version detection. --> 
            var swfVersionStr = "10.0.0";
            <!-- To use express install, set to playerProductInstall.swf, otherwise the empty string. -->
            var xiSwfUrlStr = "";
            var flashvars = {};
            var params = {};
            params.quality = "high";
            params.bgcolor = "#ffffff";
            params.allowscriptaccess = "sameDomain";
            params.allowfullscreen = "true";
            var attributes = {};
            attributes.id = "DocPlayer";
            attributes.name = "DocPlayer";
            attributes.align = "middle";
            swfobject.embedSWF(
                "http://localhost/1337iot/trunk/files/bin-debug/DocPlayer.swf", "flashContent", 
                "640", "600", 
                swfVersionStr, xiSwfUrlStr, 
                flashvars, params, attributes);
			<!-- JavaScript enabled so display the flashContent div in case it is not replaced with a swf object. -->
			swfobject.createCSS("#flashContent", "display:block;text-align:left;");
        </script>
        <div id="flashContent">

        </div>
	   	
